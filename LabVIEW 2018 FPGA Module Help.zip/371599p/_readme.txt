Windows only
------------
The files in this ZIP archive are identical to the files installed with LabVIEW 2018 FPGA Module in the labview\help directory. 

You cannot view the information in this help file if you launch the file directly from the zip file or across a networked drive. To view this help file, extract all the files in this ZIP archive and copy them to an appropriate location on your computer, then double-click the lvfpgamain.chm file.

To replace the version installed on your computer with the version extracted from the ZIP archive, copy the extracted files to labview\help. You can then access this information within LabVIEW by selecting Help�LabVIEW Help. 


Unblocking the CHM File
-----------------------
The security settings on your PC may require you to unblock the .chm file before you can view its contents. To unblock the .chm file, right-click the file, and choose Properties from the shortcut menu. If the Unblock button is visible at the bottom of the General or Security tab, click that button and try to reopen the file. You may need to repeat this procedure for the remaining .chm files in the folder.

Refer to the Microsoft Knowledge Base (article ID 896358) for more information about the security updates that prevent you from viewing HTML Help files remotely.